
public class Immoveable extends WorldObject {
	public Immoveable(String assignedName, char assignedToken){
		
		super(assignedName, assignedToken);	
	}
	
	
		
	
}